/*
 * Copyright (c) PROG's Team (Mustafa AlSihati Team).
 * This Project is currently an academic project for educational purposes.
 * This Project May be used for benefits for the working team.
 * Fully owned by the application developers.
 */

package iau.ccsit.carpooling;

public class User {
    public String username, bio;

    public User() { }

    public User(String username, String bio) {
        this.username = username;
        this.bio=bio;
    }
}
