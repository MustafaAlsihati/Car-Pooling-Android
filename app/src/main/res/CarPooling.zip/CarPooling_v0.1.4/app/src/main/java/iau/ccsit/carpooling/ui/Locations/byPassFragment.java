package iau.ccsit.carpooling.ui.Locations;

import android.content.Intent;
import android.util.Log;

import androidx.fragment.app.Fragment;

import iau.ccsit.carpooling.MainActivity;
import iau.ccsit.carpooling.MapActivity;

public class byPassFragment extends Fragment {

    @Override
    public void onStart() {
        Log.d("Pass", "onStart: Start!");
        super.onStart();
        startActivity(new Intent(getContext(), MapActivity.class));
    }

    @Override
    public void onResume() {
        Log.d("Pass", "onStart: back!");
        super.onResume();
        startActivity(new Intent(getContext(), MainActivity.class));
    }
}
