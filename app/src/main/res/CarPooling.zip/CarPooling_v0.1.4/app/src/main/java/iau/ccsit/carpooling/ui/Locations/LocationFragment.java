package iau.ccsit.carpooling.ui.Locations;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import iau.ccsit.carpooling.MapActivity;
import iau.ccsit.carpooling.PlaceAutocompleteAdapterNew;
import iau.ccsit.carpooling.R;

public class LocationFragment extends Fragment implements GoogleMap.OnMapClickListener, OnMapReadyCallback {

    private static final String TAG = "MapActivity";

    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM = 15f;
    private Boolean mLocationPermissionGranted = false;

    private Marker marker,markerClick;
    private GoogleMap map;

    private FusedLocationProviderClient mFusedLocationProviderClient;
    private AutocompleteSessionToken autocompleteSessionToken;
    private PlacesClient placesClient;
    private PlaceAutocompleteAdapterNew autoCompleteAdpater;
    private LatLng pickuplocation;


    private AutoCompleteTextView mSearchText;
    private Button mButton;
    private ImageButton myLocation, mFilter;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final View mView = getLayoutInflater().inflate(R.layout.activity_map,null);
        //try here
        mSearchText = (AutoCompleteTextView) mView.findViewById(R.id.input_search);
        myLocation = (ImageButton) mView.findViewById(R.id.myLocation);
        mFilter = (ImageButton) mView.findViewById(R.id.filterMap);
        mButton = (Button) mView.findViewById(R.id.request);

        getLocationPermission();

    }

    private void getLocationPermission(){
        Log.d(TAG, "getLocationPermission: getting  sdxz location permissions");
        String [] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION};

        if(ContextCompat.checkSelfPermission(this.getContext(),FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            if(ContextCompat.checkSelfPermission(this.getContext(),COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                mLocationPermissionGranted = true;
                initMap();
            }else{
                ActivityCompat.requestPermissions(this.getActivity(),permissions,LOCATION_PERMISSION_REQUEST_CODE);
            }

        }else{
            ActivityCompat.requestPermissions(this.getActivity(),permissions,LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void initMap(){
        Log.d(TAG,"initMap: initializing map");
        SupportMapFragment mapFragment = (SupportMapFragment) getActivity().getSupportFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(LocationFragment.this);
    }

    @Override
    public void onMapClick(LatLng latLng) {
        Log.d(TAG, "onMapClick: test");

        String pick_message = "Your pick point";

        if (markerClick != null) {

            if(!markerClick.getTitle().equals(pick_message)) {
                markerClick.remove();
                MarkerOptions options = new MarkerOptions()
                        .position(latLng)
                        .title("Your spot");
                markerClick = map.addMarker(options);
            }
        } else {
            MarkerOptions options = new MarkerOptions()
                    .position(latLng)
                    .title("Your spot");
            markerClick = map.addMarker(options);
        }

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        Toast.makeText(getContext(), "Map is Ready", Toast.LENGTH_SHORT).show();
        Log.d(TAG,"OnMapReady: map is ready");
        map = googleMap;

        if(mLocationPermissionGranted){
            getDeviceLocation();

            if(ActivityCompat.checkSelfPermission(getContext(),Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(),Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED){
                return;
            }
            map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            map.setOnMapClickListener(this);
            //enable the UI settings
            map.setMyLocationEnabled(false);
//            map.getUiSettings().setZoomControlsEnabled(true);
            autocompleteSessionToken = AutocompleteSessionToken.newInstance();
            placesClient = Places.createClient(getContext());
            init();
        }
    }


    private void init(){
        Log.d(TAG, "init: initializing");



        autoCompleteAdpater = new PlaceAutocompleteAdapterNew(getContext(),placesClient,autocompleteSessionToken);
        mSearchText.setAdapter(autoCompleteAdpater);

        mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(actionId == EditorInfo.IME_ACTION_SEARCH ||
                        actionId == EditorInfo.IME_ACTION_DONE ||
                        event.getAction() == KeyEvent.ACTION_DOWN ||
                        event.getAction() == KeyEvent.KEYCODE_ENTER){
                    geoLocate();
                }
                else{
                    Log.d(TAG, "onEditorAction: code action " + event.getAction()+". ");
                }
                return false;
            }
        });

        myLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: clicked gps icon");
                getDeviceLocation();
            }
        });

        mFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: clicked place info icon");
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
                final View mView = getLayoutInflater().inflate(R.layout.filter,null);
                mBuilder.setView(mView);

                final RadioGroup radioGroup = (RadioGroup) mView.findViewById(R.id.radiogroupid);



                mBuilder.setPositiveButton("Change", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                mBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                final AlertDialog dialog = mBuilder.create();
                dialog.show();



                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        int radioBtnId;
                        radioBtnId = radioGroup.getCheckedRadioButtonId();

                        if(radioBtnId == R.id.btnNormal){
                            map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                            Toast.makeText(v.getContext(),"Change the map type",Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        }
                        else if (radioBtnId == R.id.btnSatellite){
                            map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                            Toast.makeText(v.getContext(),"Change the map type",Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        }else{
                            Toast.makeText(v.getContext(),"You should select any item to change",Toast.LENGTH_SHORT).show();
                        }

                    }
                });

                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

            }
        });

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(markerClick != null) {
                    String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
                    Log.d(TAG, "onClick: check " + userId);

                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users").child("normal").child(userId);
                    GeoFire geoFire = new GeoFire(ref);

                    geoFire.setLocation("pickpoint", new GeoLocation(markerClick.getPosition().latitude, markerClick.getPosition().longitude));

                    pickuplocation = new LatLng(marker.getPosition().latitude, marker.getPosition().longitude);
                    //map.clear();
                    //map.addMarker(new MarkerOptions().position(pickuplocation).title("Pickup here"));
                    markerClick.setTitle("Your pick point");
                    mButton.setText("Done");
                    mButton.setEnabled(false);

                    Toast.makeText(getContext(),"Set your pick point done",Toast.LENGTH_SHORT).show();
                }
                else{
                    myLocationPickPoint();
                }
            }
        });

        hideSoftKeyboard();

    }

    private void myLocationPickPoint(){

        AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
        View mView = getLayoutInflater().inflate(R.layout.mylocation,null);

        mBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        mBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });


        mBuilder.setView(mView);
        final AlertDialog dialog = mBuilder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                markerClick = map.addMarker(new MarkerOptions().position(marker.getPosition()));
                String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users").child("normal").child(userId);
                GeoFire geoFire = new GeoFire(ref);
                geoFire.setLocation("pickpoint", new GeoLocation(marker.getPosition().latitude, marker.getPosition().longitude));

                pickuplocation = new LatLng(marker.getPosition().latitude, marker.getPosition().longitude);
                markerClick.setPosition(marker.getPosition());
                //map.clear();
                //map.addMarker(new MarkerOptions().position(pickuplocation).title("Pickup here"));
                markerClick.setTitle("Your pick point");
                mButton.setText("Done");
                mButton.setEnabled(false);
                Toast.makeText(v.getContext(),"Set your pick point done",Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(),"Please choose location of pick point",Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
    }

    private void geoLocate(){
        Log.d(TAG, "geoLocate: geolocating");
        String searchString = mSearchText.getText().toString();

        Geocoder geocoder = new Geocoder(getContext());
        List<Address> list = new ArrayList<>();
        try{
            list = geocoder.getFromLocationName(searchString, 1);
        }catch (IOException e){
            Log.e(TAG, "geoLocate: IOException: " + e.getMessage() );
        }

        if(list.size()>0){
            Address address = list.get(0);

            Log.d(TAG, "geoLocate:  found a location " + address.toString());

            moveCamera(new LatLng(address.getLatitude(), address.getLongitude()),DEFAULT_ZOOM,address.getAddressLine(0));
        }

    }

    private void getDeviceLocation(){
        Log.d(TAG, "getDeviceLocation: getting the device current location");

        mFusedLocationProviderClient  = LocationServices.getFusedLocationProviderClient(getActivity());

        try{

            if(mLocationPermissionGranted){
                final Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if(task.isSuccessful()){
                            Log.d(TAG, "onComplete: found location!");
                            Location currentLocation = (Location) task.getResult();
                            LatLng latLng = new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude());
                            map.clear();
                            map.addMarker(new MarkerOptions().position(latLng).title("My location"));
                            moveCamera(latLng,DEFAULT_ZOOM, "My location");
                        }else{
                            Log.d(TAG, "onComplete: current location is null");
                            Toast.makeText(getContext(),"unable to get current location", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }

        }catch (SecurityException e){
            Log.e(TAG, "getDeviceLocation: SecurityException: " + e.getMessage() );
        }

    }

    private void moveCamera(LatLng latLng, float zoom, String title){
        Log.d(TAG, "moveCamera: moving the camera to: lat: " + latLng.latitude + ", lng: " + latLng.longitude );
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));



        if(!title.equals("My Location")){
            map.clear();
            MarkerOptions options = new MarkerOptions()
                    .position(latLng)
                    .icon(bitmapDescriptorFromVector(getContext(),R.drawable.ic_fiber_manual_record_black_24dp))
                    .title(title);
            marker = map.addMarker(options);
        }

        hideSoftKeyboard();
    }

    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId){
        Drawable vectorDrawable = ContextCompat.getDrawable(context,vectorResId);
         vectorDrawable.setBounds(0,0,vectorDrawable.getIntrinsicWidth(),vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(),vectorDrawable.getIntrinsicHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private void hideSoftKeyboard(){
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        Log.d(TAG, "hideSoftKeyboard: calling");
    }

}