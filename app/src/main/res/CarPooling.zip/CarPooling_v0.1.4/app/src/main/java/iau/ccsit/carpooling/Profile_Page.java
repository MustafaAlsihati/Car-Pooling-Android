package iau.ccsit.carpooling;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Profile_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile__page);
    }
}
